import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.feature_selection import mutual_info_classif
from sklearn.preprocessing import LabelEncoder

accident = pd.read_csv("accident.csv")
atmospheric = pd.read_csv("atmospheric_cond.csv")
road_surface = pd.read_csv("road_surface_cond.csv")

df = pd.merge(accident, atmospheric, on="ACCIDENT_NO", how="left")
df = pd.merge(df, road_surface, on="ACCIDENT_NO", how="left")

df = df[["SEVERITY", "ATMOSPH_COND_DESC", "SURFACE_COND_DESC"]].dropna()

df["SEVERITY_ORD"] = df["SEVERITY"]

weather_heatmap = df.groupby(["ATMOSPH_COND_DESC", "SEVERITY_ORD"]).size().unstack(fill_value=0)
plt.figure(figsize=(10, 6))
sns.heatmap(weather_heatmap, annot=True, fmt='d', cmap='Blues')
plt.title("Weather Condition vs Accident Severity")
plt.xlabel("Severity")
plt.ylabel("Weather Condition")
plt.tight_layout()
plt.savefig("weather_vs_severity.png")
plt.close()

le_weather = LabelEncoder()
x_weather = le_weather.fit_transform(df["ATMOSPH_COND_DESC"]).reshape(-1, 1)
y_severity = df["SEVERITY_ORD"]
mi_weather = mutual_info_classif(x_weather, y_severity, discrete_features=True)
print("Mutual Information (Weather Condition vs Severity):", mi_weather[0])

surface_heatmap = df.groupby(["SURFACE_COND_DESC", "SEVERITY_ORD"]).size().unstack(fill_value=0)
plt.figure(figsize=(10, 6))
sns.heatmap(surface_heatmap, annot=True, fmt='d', cmap='Oranges')
plt.title("Road Surface Condition vs Accident Severity")
plt.xlabel("Severity")
plt.ylabel("Surface Condition")
plt.tight_layout()
plt.savefig("surface_vs_severity.png")
plt.close()

le_surface = LabelEncoder()
x_surface = le_surface.fit_transform(df["SURFACE_COND_DESC"]).reshape(-1, 1)
mi_surface = mutual_info_classif(x_surface, y_severity, discrete_features=True)
print("Mutual Information (Surface Condition vs Severity):", mi_surface[0])
