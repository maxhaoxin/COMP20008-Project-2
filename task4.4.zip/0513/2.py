import pandas as pd
from scipy.stats import spearmanr
from sklearn.preprocessing import LabelEncoder

accident = pd.read_csv("accident.csv")
atmospheric = pd.read_csv("atmospheric_cond.csv")
road_surface = pd.read_csv("road_surface_cond.csv")

df = accident.merge(atmospheric, on="ACCIDENT_NO", how="left")
df = df.merge(road_surface, on="ACCIDENT_NO", how="left")

df = df[[
    "SEVERITY", 
    "LIGHT_CONDITION", 
    "ROAD_GEOMETRY_DESC", 
    "SURFACE_COND_DESC", 
    "ATMOSPH_COND_DESC"
]].dropna()

le_light = LabelEncoder()
le_road = LabelEncoder()
le_surface = LabelEncoder()
le_atmos = LabelEncoder()

df["LIGHT_ENC"] = le_light.fit_transform(df["LIGHT_CONDITION"])
df["ROAD_ENC"] = le_road.fit_transform(df["ROAD_GEOMETRY_DESC"])
df["SURFACE_ENC"] = le_surface.fit_transform(df["SURFACE_COND_DESC"])
df["ATMOSPH_ENC"] = le_atmos.fit_transform(df["ATMOSPH_COND_DESC"])

def print_spearman_result(x, y, label):
    corr, p = spearmanr(x, y)
    print(f"Spearman correlation between {label} and SEVERITY:")
    print(f"  Correlation coefficient: {corr:.4f}")
    print(f"  P-value: {p:.4f}")
    if p < 0.05:
        print("  => Statistically significant\n")
    else:
        print("  => Not statistically significant\n")

print_spearman_result(df["LIGHT_ENC"], df["SEVERITY"], "LIGHT_CONDITION")
print_spearman_result(df["ROAD_ENC"], df["SEVERITY"], "ROAD_GEOMETRY_DESC")
print_spearman_result(df["SURFACE_ENC"], df["SEVERITY"], "SURFACE_COND_DESC")
print_spearman_result(df["ATMOSPH_ENC"], df["SEVERITY"], "ATMOSPH_COND_DESC")
