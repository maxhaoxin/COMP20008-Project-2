import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error

# Step 1: Load datasets
accident = pd.read_csv("accident.csv")
atmospheric = pd.read_csv("atmospheric_cond.csv")
road_surface = pd.read_csv("road_surface_cond.csv")

# Step 2: Merge datasets
df = pd.merge(accident, atmospheric, on="ACCIDENT_NO", how="left")
df = pd.merge(df, road_surface, on="ACCIDENT_NO", how="left")

# Step 3: Select relevant variables
df_model = df[["SEVERITY", "ATMOSPH_COND", "SURFACE_COND"]].dropna()

# Step 4: Standardize predictors
X = df_model[["ATMOSPH_COND", "SURFACE_COND"]]
y = df_model["SEVERITY"]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 5: Correlation analysis
corr = df_model.corr()
plt.figure(figsize=(6, 4))
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlation Matrix")
plt.tight_layout()
plt.savefig("correlation_matrix.png")  # Save figure
plt.close()

# Step 6: Build linear regression model
model = LinearRegression()
model.fit(X_scaled, y)
y_pred = model.predict(X_scaled)

# Step 7: Evaluate model
r2 = r2_score(y, y_pred)
rmse = np.sqrt(mean_squared_error(y, y_pred))

# Step 8: Output results
print("=== Linear Regression Results ===")
print(f"Coefficient for ATMOSPH_COND: {model.coef_[0]:.4f}")
print(f"Coefficient for SURFACE_COND: {model.coef_[1]:.4f}")
print(f"Intercept: {model.intercept_:.4f}")
print(f"R-squared: {r2:.4f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.4f}")
